// Function to handle API requests
const apiRequest = async (url, method, data) => {
    try {
        const response = await fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data),
        });
        return await response.json(); // Parse and return JSON response
    } catch (error) {
        console.error(`Error during ${method} request to ${url}:`, error);
        return { message: "An error occurred. Please try again." };
    }
};

// Function to handle registration form submission
document.getElementById("registerForm")?.addEventListener("submit", async function (event) {
    event.preventDefault();

    // Collect form data
    const userData = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        password: document.getElementById("password").value,
        userType: document.getElementById("userType").value, // For role selection: patient/doctor
    };

    // Make a POST request to register the user
    const response = await apiRequest("http://localhost:5001/api/users/register", "POST", userData);

    // Show alert and redirect on success
    alert(response.message);
    if (response.message === "User registered successfully") {
        window.location.href = "login.html"; // Redirect to login page
    }
});

// Function to handle login form submission
document.getElementById("loginForm")?.addEventListener("submit", async function (event) {
    event.preventDefault();

    // Collect form data
    const loginData = {
        email: document.getElementById("email").value,
        password: document.getElementById("password").value,
    };

    // Make a POST request to log in the user
    const response = await apiRequest("http://localhost:5001/api/users/login", "POST", loginData);

    if (response.token) {
        alert("Login successful!");
        // Store the JWT token in localStorage for future authenticated requests
        localStorage.setItem("token", response.token);
        window.location.href = "index.html"; // Redirect to homepage
    } else {
        alert(response.message); // Display error message
    }
});
