document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault(); // Prevent the default form submission

  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  const loginData = { email, password };

  fetch("http://localhost:5001/api/users/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(loginData),
  })
  .then((response) => response.json())
  .then((data) => {
      if (data.token) {
        // If login is successful, store the token in localStorage
        localStorage.setItem("token", data.token);
        alert("Login successful!");
        
        // Redirect based on the user role (Doctor or Patient)
        if (data.user && data.user.role === "Doctor") {
          window.location.href = "doctor.html"; // Redirect to Doctor Dashboard
        } else if (data.user && data.user.role === "Patient") {
          window.location.href = "patient.html"; // Redirect to Patient Dashboard
        } else {
          alert("Role not found. Please try again.");
        }
      } else {
        alert(data.message || "Login failed. Please try again.");
      }
  })
  .catch((error) => {
      console.error("Error:", error);
      alert("An unexpected error occurred. Please try again.");
  });
});
